#ifndef _SAC_USAGE_H_
#define _SAC_USAGE_H_

/******************************************************************************
 *
 * Usage
 *
 * Prefix: USG
 *
 *****************************************************************************/
extern void USGprintUsage();

#endif /* _SAC_USAGE_H_ */

