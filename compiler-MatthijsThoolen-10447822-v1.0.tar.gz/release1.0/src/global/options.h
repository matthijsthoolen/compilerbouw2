#ifndef _SAC_OPTIONS_H_
#define _SAC_OPTIONS_H_

#include "types.h"

extern void OPTcheckOptions( int argc, char **argv);

#endif /* _SAC_OPTIONS_H_ */
