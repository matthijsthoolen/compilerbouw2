#ifndef _NODE_HELPER_H_
#define _NODE_HELPER_H_

extern char *getShortType(type type);
extern type getNodeType(node *arg_node);
extern char *getShortNodeType(node *arg_node);

#endif
