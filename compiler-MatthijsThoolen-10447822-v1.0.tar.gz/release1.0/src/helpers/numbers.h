#ifndef _NUMBERS_H_
#define _NUMBERS_H_

int *convertToInt(char * val);
float *convertToFloat(char * val);

#endif
