#ifndef _DCC_CODE_CLEAN_H
#define _DCC_CODE_CLEAN_H

extern node *DCCmonop(node *arg_node, info *arg_info);

#endif
