#ifndef __CIVIC_H
#define __CIVIC_H

extern void printInt(int val);
extern void printFloat(float val);

extern int scanInt();
extern float scanFloat();

extern void printSpaces(int num);
extern void printNewlines(int num);

#endif
