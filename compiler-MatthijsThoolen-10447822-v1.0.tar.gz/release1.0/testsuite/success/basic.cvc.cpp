# 1 "testsuite/success/basic.cvc"
# 1 "<built-in>"
# 1 "<command-line>"
# 31 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 32 "<command-line>" 2
# 1 "testsuite/success/basic.cvc"
# 1 "testsuite/success/civic.h" 1



extern void printInt(int val);
extern void printFloat(float val);

extern int scanInt();
extern float scanFloat();

extern void printSpaces(int num);
extern void printNewlines(int num);
# 2 "testsuite/success/basic.cvc" 2

export int main() {
    int a = 5;
    int b;
    b = a + 2;
    a = 7;
    printInt(b);
 return 0;
}
